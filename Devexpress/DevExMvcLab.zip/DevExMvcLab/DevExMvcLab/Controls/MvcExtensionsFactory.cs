﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DevExpress.Web.Mvc;
using DevExpress.Web.Mvc.UI;

namespace DevExMvcLab.Controls
{
  public class MvcExtensionsFactory
  {
    static readonly MvcExtensionsFactory _instance = new MvcExtensionsFactory();

    public static MvcExtensionsFactory Instance
    {
      get { return _instance; }
    }

    public MvcGridViewExtension GridView(MvcGridViewSettings settings)
    {
      return CreateExtension<MvcGridViewExtension, MvcGridViewSettings>(settings);
    }

    public MvcGridViewExtension GridView(Action<MvcGridViewSettings> method)
    {
      return CreateExtension<MvcGridViewExtension, MvcGridViewSettings>(method);
    }

    internal static T CreateExtension<T, T1>(T1 settings) where T : MvcExtensionBase where T1 : MvcSettingsBase
    {
      return (T) CreateExtension(typeof (T), settings, HtmlHelperExtension.ViewContext);
    }

    internal static T CreateExtension<T, T1>(Action<T1> method) where T : MvcExtensionBase where T1 : MvcSettingsBase, new()
    {
      var viewContext = HtmlHelperExtension.ViewContext;
      var instance = new T1();

      method(instance);

      return (T) CreateExtension(typeof (T), instance, viewContext);
    }

    internal static MvcExtensionBase CreateExtension(Type type, MvcSettingsBase settings, ViewContext viewContext)
    {
      return (MvcExtensionBase) Activator.CreateInstance(type, new object[]
      {
        settings,
        viewContext
      });
    }
  }
}
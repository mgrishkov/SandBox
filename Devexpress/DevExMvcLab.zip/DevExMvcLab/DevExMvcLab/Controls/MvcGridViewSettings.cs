﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using DevExpress.Web.Mvc;

namespace DevExMvcLab.Controls
{
  public class MvcGridViewSettings : MvcSettingsBase
  {
    public Boolean ShowToolbar { get; set; }

    public GridViewSettings GridViewSettings { get; private set; }

    public MenuSettings MenuSettings { get; private set; }

    public MvcGridViewSettings()
    {
      GridViewSettings = new GridViewSettings();

      var ms = new MenuSettings {ShowAsToolbar = true};

      ms.Items.Add(item =>
      {
        item.Name = @"miRefresh";
        item.Text = String.Empty;
        item.Image.ToolTip = "Refresh";
        item.Image.Url = "/Images/24x24/refresh.png";
        item.ItemStyle.Cursor = "Hand";
      });

      MenuSettings = ms;
    }
  }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DevExMvcLab.Controls
{
  public class MvcExtensionBase
  {
    public MvcExtensionBase()
    {
    }

    public MvcExtensionBase(MvcSettingsBase settings) : this(settings, null)
    {
    }

    public MvcExtensionBase(MvcSettingsBase settings, ViewContext viewContext)
    {
    }

    public virtual MvcHtmlString GetHtml()
    {
      return MvcHtmlString.Empty;
    }
  }
}
﻿using System.Web.Mvc;
using DevExpress.Web.ASPxClasses.Internal;

namespace DevExMvcLab.Controls
{
  public static class HtmlHelperExtension
  {
    private const string HtmlHelperKey = "MvcHtmlHelper";

    internal static HtmlHelper HtmlHelper
    {
      get { return HttpUtils.GetContextValue<HtmlHelper>(HtmlHelperKey, null); }
    }

    internal static ViewContext ViewContext
    {
      get { return HtmlHelper == null ? null : HtmlHelper.ViewContext; }
    }

    public static MvcExtensionsFactory Eurospan(this HtmlHelper helper)
    {
      HttpUtils.SetContextValue(HtmlHelperKey, helper);

      return MvcExtensionsFactory.Instance;
    }
  }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using DevExpress.Web.Mvc;

namespace DevExMvcLab.Controls
{
  public class MvcGridViewExtension : MvcExtensionBase
  {
    GridViewExtension _gridView;
    MenuExtension _menu;

    MvcGridViewSettings _settings;

    public MvcGridViewExtension(MvcGridViewSettings settings) : base(settings)
    {
      _settings = settings;

      _gridView = new GridViewExtension(settings.GridViewSettings);
      _menu = new MenuExtension(settings.MenuSettings);
    }

    public MvcGridViewExtension(MvcGridViewSettings settings, ViewContext viewContext) : base(settings, viewContext)
    {
      _settings = settings;

      _gridView = new GridViewExtension(settings.GridViewSettings, viewContext);
      _menu = new MenuExtension(settings.MenuSettings, viewContext);
    }

    public override MvcHtmlString GetHtml()
    {
      var sb = new StringBuilder();

      if(_settings.ShowToolbar)
        sb.Append(_menu.GetHtml().ToHtmlString());

      sb.Append(_gridView.GetHtml().ToHtmlString());

      return new MvcHtmlString(sb.ToString());
    }
  }
}
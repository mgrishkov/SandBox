﻿using System;
using System.Data;
using DevExpress.Web.Mvc;

namespace DevExMvcLab.Utils
{
  public class TreeViewUtils
  {
    public static void CreateTreeViewNodesRecursive(DataTable table, MVCxTreeViewNodeCollection nodesCollection, String nameField, String textField, String linkField, String parentID)
    {
      for(var i = 0; i < table.Rows.Count; i++)
      {
        if(table.Rows[i][linkField].ToString() != parentID)
          continue;

        var node = nodesCollection.Add(table.Rows[i][textField].ToString(), table.Rows[i][nameField].ToString());

        CreateTreeViewNodesRecursive(table, node.Nodes, nameField, textField, linkField, node.Name);
      }
    }
  }
}
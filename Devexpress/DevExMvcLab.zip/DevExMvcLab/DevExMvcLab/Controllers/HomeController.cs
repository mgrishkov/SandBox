﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DevExMvcLab.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index()
    {
      ViewBag.Message = "Welcome to DevExpress Extensions for ASP.NET MVC!";

      var source = new DataTable();

      source.Columns.Add("ID", typeof(Int32));
      source.Columns.Add("ParentID", typeof(Int32));
      source.Columns.Add("Name", typeof(String));

      source.Rows.Add(new object[] { 1, 0, "Root" });
      source.Rows.Add(new object[] { 2, 1, "Node 1" });
      source.Rows.Add(new object[] { 3, 1, "Node 2" });
      source.Rows.Add(new object[] { 4, 1, "Node 3" });
      source.Rows.Add(new object[] { 5, 1, "Node 4" });
      source.Rows.Add(new object[] { 6, 2, "1-st child of Node 1" });
      source.Rows.Add(new object[] { 7, 2, "2-nd child of Node 1" });
      source.Rows.Add(new object[] { 8, 6, "Node 8" });
      source.Rows.Add(new object[] { 9, 6, "Node 9" });
      source.Rows.Add(new object[] { 10, 6, "Node 10" });
      source.Rows.Add(new object[] { 11, 9, "Node 11" });
      source.Rows.Add(new object[] { 12, 9, "Node 12" });

      return View(source);
    }

    public ActionResult TreeViewPartial(String dropDownEditName)
    {
      ViewBag.DropDownEditName = dropDownEditName;

      var source = new DataTable();

      source.Columns.Add("ID", typeof(Int32));
      source.Columns.Add("ParentID", typeof(Int32));
      source.Columns.Add("Name", typeof(String));

      source.Rows.Add(new object[] { 1, 0, "Root" });
      source.Rows.Add(new object[] { 2, 1, "Node 1" });
      source.Rows.Add(new object[] { 3, 1, "Node 2" });
      source.Rows.Add(new object[] { 4, 1, "Node 3" });
      source.Rows.Add(new object[] { 5, 1, "Node 4" });
      source.Rows.Add(new object[] { 6, 2, "1-st child of Node 1" });
      source.Rows.Add(new object[] { 7, 2, "2-nd child of Node 1" });
      source.Rows.Add(new object[] { 8, 6, "Node 8" });
      source.Rows.Add(new object[] { 9, 6, "Node 9" });
      source.Rows.Add(new object[] { 10, 6, "Node 10" });
      source.Rows.Add(new object[] { 11, 9, "Node 11" });
      source.Rows.Add(new object[] { 12, 9, "Node 12" });

      return PartialView(source);
    }
  }
}

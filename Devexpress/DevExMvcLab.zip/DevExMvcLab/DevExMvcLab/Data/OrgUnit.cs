﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace DevExMvcLab.Data
{
  public class OrgUnit 
  {
    public Int32 ID { get; set; }
    public Int32 ParentID { get; set; }

    public String Name { get; set; }
  }
}